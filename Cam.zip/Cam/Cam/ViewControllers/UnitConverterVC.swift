//
//  UnitConverterVC.swift
//  Cam
//
//  Created by IOS on 01/02/24.
//

import UIKit

class UnitConverterVC: UIViewController {
    
    @IBOutlet weak var clvUnit: UICollectionView!
    @IBOutlet weak var btnDrop1: UIButton!
    @IBOutlet weak var btnDrop2: UIButton!
    
    @IBOutlet weak var lblS1: UILabel!
    @IBOutlet weak var lblS2: UILabel!
    
    @IBOutlet weak var txtDrop1: UITextField!
    @IBOutlet weak var txtDrop2: UITextField!
    @IBOutlet weak var imgArrow1: UIImageView!
    @IBOutlet weak var imgArrow2: UIImageView!

    var arrCategory = Category.allCases
    var selectedIndex = 0
    
    let dropDown1 = DropDown()
    let dropDown2 = DropDown()
    
    var titles = [String]()
    var symbols = [String]()
    
    var selectedDropIndex1 = 0
    var selectedDropIndex2 = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        txtDrop1.delegate = self
        txtDrop2.delegate = self
        
        clvUnit.delegate = self
        clvUnit.dataSource = self
        clvUnit.register(UINib(nibName: "UnitCalcCell", bundle: nil), forCellWithReuseIdentifier: "UnitCalcCell")
        setupChooseDropDown1()
        setupChooseDropDown2()
        txtDrop1.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        txtDrop2.addTarget(self, action: #selector(textFieldDidChange(_:)), for: .editingChanged)
        setupDropDownAndView(type: arrCategory[selectedIndex])
        
        let attributes: [NSAttributedString.Key: Any] = [NSAttributedString.Key.foregroundColor: UIColor(hex: "84D552", alpha: 0.5)]
        txtDrop1.attributedPlaceholder = NSAttributedString(string: "0", attributes: attributes)
        txtDrop2.attributedPlaceholder = NSAttributedString(string: "0", attributes: attributes)
    }
    
    
    @objc func textFieldDidChange(_ textField: UITextField) {
        guard let text = textField.text else { return }
        let selectedCategory = arrCategory[selectedIndex]
        let viewModel = UnitDataManager()
        let u1 = viewModel.selectedtUnits(category: selectedCategory)[selectedDropIndex1]
        let u2 = viewModel.selectedtUnits(category: selectedCategory)[selectedDropIndex2]
        
        if textField == txtDrop1 {
            let result = viewModel.convert(value: text, unit1: u1, unit2: u2)
            if result == 0.0 {
                txtDrop2.text = ""
            } else {
                txtDrop2.text = "\(result)"
            }
        } else if textField == txtDrop2 {
            let result = viewModel.convert(value: text, unit1: u2, unit2: u1)
            if result == 0.0 {
                txtDrop1.text = ""
            } else {
                txtDrop1.text = "\(result)"
            }
        }
    }
    
    func setupDropDownAndView(type: Category) {
        txtDrop1.becomeFirstResponder()
        txtDrop1.text = ""
        txtDrop2.text = ""
        
        let val = UnitDataManager()
        titles = val.selectedUnitTitlesAndSymbols(category: type).map { title, symbol in
            return title
        }
        symbols = val.selectedUnitTitlesAndSymbols(category: type).map { title, symbol in
            return symbol
        }
        
        btnDrop1.setTitle(titles[0], for: .normal)
        btnDrop2.setTitle(titles[1], for: .normal)
        
        lblS1.text = symbols[0].capitalized
        lblS2.text = symbols[1].capitalized
        selectedDropIndex1 = 0
        selectedDropIndex2 = 1
        
        setupChooseDropDown1()
        setupChooseDropDown2()
    }
    
    func setupChooseDropDown1() {
        dropDown1.anchorView = btnDrop1
        dropDown1.direction = .bottom
        dropDown1.bottomOffset = CGPoint(x: 0, y: btnDrop1.bounds.height)
        dropDown1.textFont = UIDevice().userInterfaceIdiom == .pad ? UIFont.systemFont(ofSize: 19):UIFont.systemFont(ofSize: 20, weight: .medium)
        dropDown1.selectionBackgroundColor = .clear
        dropDown1.textColor = .white
        dropDown1.selectedTextColor = UIColor(hex: "84D552")
        dropDown1.cornerRadius = 10
        dropDown1.backgroundColor = UIColor(hex: "36454f")
        dropDown1.dataSource = titles
        
        // Action triggered on selection
        dropDown1.selectionAction = { [weak self] (index, item) in
            self?.imgArrow1.isHighlighted = false
            self?.btnDrop1.setTitle(item, for: .normal)
            self?.lblS1.text = self?.symbols[index].capitalized
            self?.selectedDropIndex1 = index
            guard let txt = self?.txtDrop1 else { return }
            self?.textFieldDidChange(txt)
            self?.txtDrop1.becomeFirstResponder()
        }
        dropDown1.cancelAction = {
            self.imgArrow1.isHighlighted = false
            self.txtDrop1.becomeFirstResponder()
        }
    }
    
    func setupChooseDropDown2() {
        dropDown2.anchorView = btnDrop2
        dropDown2.direction = .bottom
        dropDown2.bottomOffset = CGPoint(x: 0, y: btnDrop2.bounds.height)
        dropDown2.textFont = UIDevice().userInterfaceIdiom == .pad ? UIFont.systemFont(ofSize: 19):UIFont.systemFont(ofSize: 20, weight: .semibold)
        dropDown2.selectionBackgroundColor = .clear
        dropDown2.textColor = .white
        dropDown2.selectedTextColor = UIColor(hex: "84D552")
        dropDown2.cornerRadius = 10
        dropDown2.backgroundColor = UIColor(hex: "36454f")
        dropDown2.dataSource = titles
        
        // Action triggered on selection
        dropDown2.selectionAction = { [weak self] (index, item) in
            self?.imgArrow2.isHighlighted = false
            self?.btnDrop2.setTitle(item, for: .normal)
            self?.lblS2.text = self?.symbols[index].capitalized
            self?.selectedDropIndex2 = index
            guard let txt = self?.txtDrop1 else { return }
            self?.textFieldDidChange(txt)
            self?.txtDrop2.becomeFirstResponder()
        }
        dropDown2.cancelAction = {
            self.imgArrow2.isHighlighted = false
            self.txtDrop2.becomeFirstResponder()
        }
    }
    
    @IBAction func onBtnBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func onBtnDrop1(_ sender: UIButton) {
        if sender.tag == 1 {
            txtDrop1.resignFirstResponder()
            dropDown1.show()
            imgArrow1.isHighlighted = true
        } else {
            txtDrop2.resignFirstResponder()
            dropDown2.show()
            imgArrow2.isHighlighted = true
        }
    }
}

extension UnitConverterVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        arrCategory.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UnitCalcCell", for: indexPath) as? UnitCalcCell else { return .init() }
        cell.lblTitle.text = arrCategory[indexPath.row].rawValue
        if selectedIndex == indexPath.row {
            cell.viewbg.backgroundColor = UIColor(hex: "1D1D1D")
            cell.lblTitle.textColor =  UIColor(hex: "84D552")
        } else {
            cell.viewbg.backgroundColor = .clear
            cell.lblTitle.textColor =  .white.withAlphaComponent(0.6)
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedIndex = indexPath.row
        clvUnit.reloadData()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            self.clvUnit.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
        }
        setupDropDownAndView(type: arrCategory[indexPath.row])
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let label = UILabel()
        label.text = arrCategory[indexPath.row].rawValue
        label.sizeToFit()
        
        return CGSize(width: label.frame.width + 30, height: collectionView.frame.height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
}


extension UnitConverterVC: UITextFieldDelegate {
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        let allowedCharacters = CharacterSet(charactersIn: "0123456789.")
        if string.rangeOfCharacter(from: allowedCharacters.inverted) != nil {
            return false
        }
        
        let newText = (textField.text! as NSString).replacingCharacters(in: range, with: string)
        if newText.rangeOfCharacter(from: allowedCharacters.inverted) != nil {
            return false
        }
        return true
    }
}

extension UIColor {
    convenience init(hex: String, alpha: CGFloat = 1.0) {
        var hexSanitized = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        hexSanitized = hexSanitized.replacingOccurrences(of: "#", with: "")
        var rgb: UInt64 = 0
        Scanner(string: hexSanitized).scanHexInt64(&rgb)
        let red = CGFloat((rgb & 0xFF0000) >> 16) / 255.0
        let green = CGFloat((rgb & 0x00FF00) >> 8) / 255.0
        let blue = CGFloat(rgb & 0x0000FF) / 255.0
        self.init(red: red, green: green, blue: blue, alpha: alpha)
    }
}

