//
//  ViewController.swift
//  Cam
//
//  Created by IOS on 26/01/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var lblNoHistory: UILabel!
    @IBOutlet weak var lblInputWorkings: UITextView!
    @IBOutlet weak var lblTotalResults: UILabel!
    @IBOutlet weak var tblHistory: UITableView!
    @IBOutlet weak var btnHistory: UIButton!
    @IBOutlet weak var viewHistory: UIView!
    @IBOutlet weak var btnBackClear: ButtonView!
    
    var workings:String = ""
    var arrHistoryModel: [HistoryModel] = []
    var isEqualTap = false
    private var textViewObserver: NSKeyValueObservation?
    
    deinit {
        textViewObserver?.invalidate()
    }
    
    func textViewDidChange(newValue: String) {
        adjustFontSize()
    }
    func adjustFontSize() {
        let fixedWidth = lblInputWorkings.frame.size.width
        var newSize = lblInputWorkings.sizeThatFits(CGSize(width: fixedWidth, height: lblInputWorkings.frame.size.height))
        
        // You can adjust these values according to your preference
        let maxFontSize: CGFloat = 17 // Maximum font size
        let minFontSize: CGFloat = 10 // Minimum font size
        
        var fontSize = lblInputWorkings.font!.pointSize
        if newSize.height > lblInputWorkings.frame.size.height {
            while newSize.height > lblInputWorkings.frame.size.height && fontSize > minFontSize {
                fontSize -= 1
                lblInputWorkings.font = UIFont.systemFont(ofSize: fontSize, weight: .bold)
                let updatedSize = lblInputWorkings.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
                newSize.height = updatedSize.height
            }
        } else {
            while newSize.height < lblInputWorkings.frame.size.height && fontSize < maxFontSize {
                fontSize += 1
                lblInputWorkings.font = UIFont.systemFont(ofSize: fontSize, weight: .bold)
                let updatedSize = lblInputWorkings.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
                newSize.height = updatedSize.height
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set up observer for text changes
        lblInputWorkings.delegate = self
        textViewObserver = lblInputWorkings.observe(\.text, options: [.new, .old]) { [weak self] (textView, change) in
            guard let newValue = change.newValue as? String else { return }
            // Call the method to adjust font size or perform any other actions based on the new text value
            self?.textViewDidChange(newValue: newValue)
        }
        clearAll()
        tblHistory.register(.init(nibName: "HistoryCalcCell", bundle: nil), forCellReuseIdentifier: "HistoryCalcCell")
        tblHistory.delegate = self
        tblHistory.dataSource = self
        tblHistory.reloadData()
        
        //        let verticalInset = (lblInputWorkings.bounds.size.height - lblInputWorkings.contentSize.height) / 2
        //        lblInputWorkings.contentInset = UIEdgeInsets(top: verticalInset, left: 0, bottom: 0, right: 0)
        
        if UIDevice().userInterfaceIdiom == .pad {
            btnBackClear.imageEdgeInsets = UIEdgeInsets(top: 40.0, left: 40.0, bottom: 40.0, right: 40.0)
        }
        viewHistory.alpha = 0.0
        lblInputWorkings.inputView = UIView()
        lblInputWorkings.becomeFirstResponder()
    }
    
    func clearAll() {
        lblInputWorkings.font = UIFont.systemFont(ofSize: 50, weight: .bold)
        workings = ""
        lblInputWorkings.text = ""
        lblTotalResults.text = ""
    }
    
    func calculateResultRunTime() {
        lblInputWorkings.textColor = .white
        if(validInput() && isValidInput()) {
            if workings.last != "." {
                let checkedWorkingsForPercent = workings.replacingOccurrences(of: "%", with: "*0.01")
                let expression = NSExpression(format: checkedWorkingsForPercent)
                //                let result = expression.expressionValue(with: nil, context: nil) as! Double
                let result = expression.toFloatingPoint().expressionValue(with: nil, context: nil)
                let resultString = String(describing: result ?? 0)
                //                let resultString = formatResult(result: result)
                if resultString == "inf" {
                    lblTotalResults.text = "Result is infinity or NaN"
                    return
                }
                lblTotalResults.text = resultString
            }
        }
    }
    func calculateResult() {
        if(validInput() && isValidInput()) {
            let checkedWorkingsForPercent = workings.replacingOccurrences(of: "%", with: "*0.01")
            let expression = NSExpression(format: checkedWorkingsForPercent)
            //            let result = expression.expressionValue(with: nil, context: nil) as! Double
            //            let resultString = formatResult(result: result)
            let result = expression.toFloatingPoint().expressionValue(with: nil, context: nil)
            let resultString = String(describing: result ?? 0)
            if resultString == "inf" {
                lblTotalResults.text = "Result is infinity or NaN"
                return
            }
            lblTotalResults.text = resultString
            
            if lblTotalResults.text != "" && lblInputWorkings.text != "" {
                HistoryDataManager.shared.addModel(input: lblInputWorkings.text ?? "", total: lblTotalResults.text ?? "")
                lblInputWorkings.text = lblTotalResults.text ?? ""
                lblTotalResults.text = ""
                lblInputWorkings.textColor = UIColor(hex: "84D552")
                isEqualTap = true
            }
        } else {
            showError()
        }
    }
    
    func showError(msg: String = "Invalid formate used.") {
        let alert = UIAlertController(
            title: "Invalid Input",
            message: msg,
            preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Okay", style: .default))
        self.present(alert, animated: true, completion: nil)
    }
    
    func validInput() ->Bool {
        var count = 0
        var funcCharIndexes = [Int]()
        
        for char in workings
        {
            if(specialCharacter(char: char))
            {
                funcCharIndexes.append(count)
            }
            count += 1
        }
        
        var previous: Int = -1
        
        for index in funcCharIndexes {
            if(index == 0) {
                return false
            }
            
            if(index == workings.count - 1) {
                return false
            }
            if (previous != -1) {
                if(index - previous == 1) {
                    return false
                }
            }
            previous = index
        }
        return true
    }
    
    func isValidInput() -> Bool {
        
        guard let lastval = workings.last else { return false }
        var openCount = 0
        var closeCount = 0
        
        for char in workings {
            if char == "(" {
                openCount += 1
            } else if char == ")" {
                closeCount += 1
            }
        }
        
        if openCount != closeCount {
            return false
        }
        
        if !isValidCalculation(workings) {
            return false
        }
        
        if workings.last == "." && workings.count > 0 {
            return false
        }
        if lastval == "%" {
            if workings.contains("(") || workings.contains(")") {
                return isValidString(workings)
            }
        }
        
        if lastval.isOperator {
            return false
        }
        if lastval == "(" {
            return false
        }
        
        if workings.contains("(") || workings.contains(")") {
            return isValidString(workings)
        }
        return true
    }
    
    func isValidCalculation(_ expression: String) -> Bool {
        var components: [String] = []
        var currentComponent = ""
        var parenCount = 0
        
        for char in expression {
            if char == "(" {
                parenCount += 1
                if parenCount == 1 {
                    if !currentComponent.isEmpty {
                        components.append(currentComponent)
                        currentComponent = ""
                    }
                }
            } else if char == ")" {
                parenCount -= 1
                if parenCount == 0 {
                    currentComponent += String(char)
                    components.append(currentComponent)
                    currentComponent = ""
                    continue
                }
            }
            
            if parenCount > 0 {
                currentComponent += String(char)
            } else {
                if char.isWhitespace {
                    continue
                }
                if "+-*/".contains(char) {
                    if !currentComponent.isEmpty {
                        components.append(currentComponent)
                        currentComponent = ""
                    }
                    components.append(String(char))
                } else {
                    currentComponent += String(char)
                }
            }
        }
        
        if !currentComponent.isEmpty {
            components.append(currentComponent)
        }
        
        for component in components {
            let ncomp = component.replacingOccurrences(of: "(", with: "").replacingOccurrences(of: ")", with: "").replacingOccurrences(of: "%", with: "")
            if "+-*/".contains(ncomp) || ncomp == "" {
                continue
            }
            
            if let number = Double(ncomp) {
                // Check if the number has more than one decimal point
                let decimalCount = component.components(separatedBy: ".").count - 1
                if decimalCount > 1 {
                    return false
                }
            } else {
                return false // Invalid number
            }
        }
        
        return true
    }
    
    func isValidString(_ input: String) -> Bool {
        var previousIndex = input.startIndex
        
        while let closingParenthesisIndex = input[previousIndex...].firstIndex(of: ")") {
            // Check if there is a character after ")"
            let nextIndex = input.index(after: closingParenthesisIndex)
            
            if nextIndex < input.endIndex {
                // Get the character after ")"
                let characterAfterClosingParenthesis = input[nextIndex]
                
                if characterAfterClosingParenthesis == "(" {
                    return false
                }
                // Check if the character is a digit
                if CharacterSet.decimalDigits.contains(characterAfterClosingParenthesis.unicodeScalars.first!) {
                    return false
                }
                
                if let openingParenthesisIndex = input[nextIndex...].firstIndex(of: "(") {
                    let substringBetweenParentheses = input[nextIndex..<openingParenthesisIndex]
                    if substringBetweenParentheses == "" {
                        return false
                    }
                    if substringBetweenParentheses.allSatisfy({ !$0.isWhitespace && !$0.isLetter && !$0.isNumber }) {
                        previousIndex = input.index(after: openingParenthesisIndex)
                    } else {
                        return false
                    }
                } else {
                    // No "(" found after ")"
                    return true
                }
            } else {
                break
            }
        }
        return true
    }
    
    func specialCharacter (char: Character) -> Bool {
        if(char == "*") {
            return true
        }
        if(char == "/") {
            return true
        }
        if(char == "+") {
            return true
        }
        return false
    }
    
    func formatResult(result: Decimal) -> String {
        let resultNSDecimalNumber = NSDecimalNumber(decimal: result)
        return resultNSDecimalNumber.stringValue
    }
    
    func addToWorkings(value: String) {
        lblInputWorkings.textColor = .white
        if isEqualTap {
            clearAll()
        }
        if workings.last == "%" && value != "%" {
            clearAll()
        }
        if !workings.isEmpty {
            let lastChar = workings.last!
            // Check if the last character is an operator and the new value is also an operator
            if specialCharsToCheck(char: lastChar) && specialCharsToCheck(char: value.first!) {
                // Replace the last operator with the new one
                workings.removeLast()
            }
        }
        
        workings = workings + value
        lblInputWorkings.text = workings
        
        if workings.last != "." && workings.count > 0 {
            calculateResultRunTime()
        }
        
        if workings.last == "%" && workings.count > 0 {
            //            clearAll()
            if workings.count != 1 {
                calculateResultRunTime()
            }
        } else if workings.last != "%" && workings.count > 0 {
            calculateResultRunTime()
        }
        isEqualTap = false
    }
    
    func specialCharsToCheck(char: Character) -> Bool {
        if (char == "*") || (char == "/") || (char == "+") || (char == "-") || (char == ".") || (char == "%") {
            return true
        }
        return false
    }
    
    func togglePositiveNegative() {
        lblInputWorkings.textColor = .white
        if isEqualTap {
            clearAll()
        }
        guard !workings.isEmpty else {
            return
        }
        
        let lastCharIndex = workings.index(before: workings.endIndex)
        let lastChar = workings[lastCharIndex]
        
        if lastChar.isNumber {
            
            let components = workings.split { !($0.isNumber || $0 == ".") }
            print(components) // Debugging: Print components to understand its content
            let lastNumberString = components.last
            if lastNumberString?.count ?? 0 > 35 {
                showError(msg: "Only 35 characters are valid.")
                return
            }
            // Last character is a digit, toggle positive/negative and add parentheses
            let lastNumber = findLastNumber()
            if lastNumber == 0.0 {
                return
            }
            let newNumber = -lastNumber
            replaceLastNumberWithParentheses(newNumber: newNumber)
        } else if lastChar == "+" || lastChar == "-" {
            // If the last character is already a positive/negative sign, remove it
            workings.removeLast()
            lblInputWorkings.text = workings
        } else if lastChar == ")" {
            // If the last character is a closing parenthesis, remove it and its matching opening parenthesis
            toggleSignOfNumberInsideParentheses()
        } else {
            showError()
        }
        calculateResultRunTime()
    }
    
    func toggleSignOfNumberInsideParentheses() {
        guard let openingParenIndex = findOpeningParenIndex() else {
            return
        }
        let startIndex = workings.index(after: openingParenIndex)
        let endIndex = workings.index(before: workings.endIndex)
        let rangeInsideParentheses = startIndex..<endIndex
        let numberInsideParentheses = String(workings[rangeInsideParentheses]) // Convert Substring to String
        let decimalNumber = Decimal(string: numberInsideParentheses) ?? 0
        
        // Get the number of digits after the dot
        if let dotIndex = numberInsideParentheses.firstIndex(of: ".") {
            let digitsAfterDot = numberInsideParentheses.distance(from: dotIndex, to: numberInsideParentheses.endIndex) - 1
            //            print("Digits after dot:", digitsAfterDot)
            // Create a number formatter to handle the desired precision
            let numberFormatter = NumberFormatter()
            numberFormatter.minimumFractionDigits = digitsAfterDot
            numberFormatter.maximumFractionDigits = digitsAfterDot
            
            // Format the decimal number using the number formatter
            if let formattedNumber = numberFormatter.string(for: decimalNumber) {
                //                print(formattedNumber) // Output: -8.22
                let newNumber = -decimalNumber
                replaceNumberInsideParentheses(newNumber: newNumber, newNumberstr: formattedNumber.replacingOccurrences(of: "-", with: ""), range: rangeInsideParentheses)
            }
        } else {
            print("No dot found in the string.")
            let newNumber = -decimalNumber
            replaceNumberInsideParentheses(newNumber: newNumber, range: rangeInsideParentheses)
        }
    }
    
    func replaceNumberInsideParentheses(newNumber: Decimal, newNumberstr: String = "", range: Range<String.Index>) {
        var formattedNumber = formatResult(result: newNumber)
        if newNumberstr != "" {
            formattedNumber = newNumberstr
        }
        // Remove parentheses if present
        let resultString = formattedNumber.replacingOccurrences(of: "(", with: "").replacingOccurrences(of: ")", with: "")
        
        workings.replaceSubrange(range, with: resultString)
        //        calculatorWorkings.text = workings
        if let range = workings.range(of: "(\(resultString))", options: .backwards) {
            workings.replaceSubrange(range, with: resultString)
            lblInputWorkings.text = workings
        } else {
            print("Substring not found")
        }
    }
    
    func findOpeningParenIndex() -> String.Index? {
        var index = workings.endIndex
        var parenthesesCount = 0
        
        while index != workings.startIndex {
            index = workings.index(before: index)
            
            if workings[index] == ")" {
                parenthesesCount += 1
            } else if workings[index] == "(" {
                if parenthesesCount == 0 {
                    return index
                } else {
                    parenthesesCount -= 1
                }
            } else if workings[index] == "-" && index != workings.startIndex && workings[workings.index(before: index)] == "(" {
                // Skip the negative sign directly before the opening parenthesis
                return workings.index(before: index)
            }
        }
        print("No matching opening parenthesis found.")
        return nil
    }
    func replaceLastNumberWithParentheses(newNumber: Decimal) {
        let components = workings.split { !($0.isNumber || $0 == ".") }
        if let lastNumberString = components.last {
            let range = workings.range(of: lastNumberString, options: .backwards)
            if let range = range {
                let formattedNumber = "(\(newNumber))"
                workings.replaceSubrange(range, with: formattedNumber)
                lblInputWorkings.text = workings
            }
        }
    }
    
    func getNumberOfDecimalPlaces(value: Double) -> Int {
        let decimalSeparator = Locale.current.decimalSeparator ?? "."
        let components = String(value).components(separatedBy: decimalSeparator)
        
        if components.count > 1 {
            return components[1].count
        }
        return 0
    }
    
    func findLastNumber() -> Decimal {
        let components = workings.split { !($0.isNumber || $0 == ".") }
        print(components) // Debugging: Print components to understand its content
        if let lastNumberString = components.last, let lastNumber = Decimal(string: String(lastNumberString)) {
            return lastNumber
        }
        return 0
    }
    
    @IBAction func onBtnUnit(_ sender: UIButton) {
        if let nextViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "UnitConverterVC") as? UnitConverterVC {
            navigationController?.pushViewController(nextViewController, animated: true)
        }
    }
    
    @IBAction func percentTap(_ sender: ButtonView) {
        if let last = workings.last, last.isDigit || last == ")"  {
            if workings.count >= 1  {
                addToWorkings(value: "%")
            }
        } else {
            if workings.last == "%" {
                return
            }
            if workings.count >= 1 {
                showError()
            }
        }
    }
    
    @IBAction func divideTap(_ sender: ButtonView) {
        addToWorkings(value: "/")
    }
    
    @IBAction func timesTap(_ sender: ButtonView) {
        addToWorkings(value: "*")
    }
    
    @IBAction func minusTap(_ sender: ButtonView) {
        addToWorkings(value: "-")
    }
    
    @IBAction func plusTap(_ sender: ButtonView) {
        addToWorkings(value: "+")
    }
    
    @IBAction func decimalTap(_ sender: ButtonView) {
        if isValidCalculation(workings + ".") {
            addToWorkings(value: ".")
        }
    }
    
    @IBAction func zeroTap(_ sender: ButtonView) {
        if workings.last == "0" && workings.count == 1 {
            return
        }
        addToWorkings(value: "0")
    }
    
    @IBAction func oneTap(_ sender: ButtonView) {
        addToWorkings(value: "1")
    }
    
    @IBAction func twoTap(_ sender: ButtonView) {
        addToWorkings(value: "2")
    }
    
    @IBAction func threeTap(_ sender: ButtonView) {
        addToWorkings(value: "3")
    }
    
    @IBAction func fourTap(_ sender: ButtonView) {
        addToWorkings(value: "4")
    }
    
    @IBAction func fiveTap(_ sender: ButtonView) {
        addToWorkings(value: "5")
    }
    
    @IBAction func sixTap(_ sender: ButtonView) {
        addToWorkings(value: "6")
    }
    
    @IBAction func sevenTap(_ sender: ButtonView) {
        addToWorkings(value: "7")
    }
    
    @IBAction func eightTap(_ sender: ButtonView) {
        addToWorkings(value: "8")
    }
    
    @IBAction func nineTap(_ sender: ButtonView) {
        addToWorkings(value: "9")
    }
    
    @IBAction func positiveNegativeTAP(_ sender: ButtonView) {
        var openCount = 0
        var closeCount = 0
        
        for char in workings {
            if char == "(" {
                openCount += 1
            } else if char == ")" {
                closeCount += 1
            }
        }
        
        if openCount != closeCount {
            showError()
            return
        }
        if !validInput() {
            showError()
            return
        }
        
        if workings.last == "-" {
            showError()
            return
        }
        togglePositiveNegative()
    }
    
    @IBAction func equalsTap(_ sender: ButtonView) {
        if lblInputWorkings.textColor != .white {
            return
        }
        
        if workings.last == "%" && workings.count > 1 {
            calculateResult()
        }
        
        if workings.last != "%" && workings.count > 0 {
            calculateResult()
        }
        
        if workings == "" {
            lblTotalResults.text = ""
            lblInputWorkings.text = ""
        }
        
    }
    
    @IBAction func allClearTap(_ sender: ButtonView) {
        clearAll()
    }
    
    @IBAction func backTap(_ sender: ButtonView) {
        lblInputWorkings.textColor = .white
        if isEqualTap {
            clearAll()
        }
        if(!workings.isEmpty) {
            workings.removeLast()
            lblInputWorkings.text = workings
            calculateResultRunTime()
            if workings == "" {
                clearAll()
            }
        }
    }
    
    @IBAction func onBtnHistory(_ sender: UIButton) {
        
        UIView.animate(withDuration: 0.3) {
            self.viewHistory.isHidden.toggle()
            self.viewHistory.alpha = self.viewHistory.isHidden ? 0.0 : 1.0
        }
        
        arrHistoryModel = HistoryDataManager.shared.arrHistoryModel
        lblNoHistory.isHidden = arrHistoryModel.count == 0 ? false:true
        
        tblHistory.reloadData()
        if arrHistoryModel.count > 0 {
            let indexPath = IndexPath(row: arrHistoryModel.count - 1, section: 0)
            tblHistory.scrollToRow(at: indexPath, at: .bottom, animated: true)
        }
    }
    
    @IBAction func onBtnClearHistory(_ sender: Any) {
        HistoryDataManager.shared.removeAll()
        tblHistory.reloadData()
        UIView.animate(withDuration: 0.3) {
            self.viewHistory.isHidden = true
            self.viewHistory.alpha = 0
        }
    }
}

extension ViewController: UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text.isEmpty {
            let pasteboard = UIPasteboard.general
            if let _ = pasteboard.string {
                return false
            } else {
                return true
            }
        }
        // Disable cut, copy, and paste operations
        let pasteboard = UIPasteboard.general
        if let _ = pasteboard.string {
            return false
        }
        return true
    }
}

extension ViewController: UITableViewDataSource, UITableViewDelegate {
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        arrHistoryModel.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "HistoryCalcCell") as? HistoryCalcCell else {
            return .init()
        }
        let val = arrHistoryModel[indexPath.row]
        cell.lblCalc.text = val.input
        cell.lblResult.text = val.total
        return cell
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let val = arrHistoryModel[indexPath.row]
        lblInputWorkings.text = val.input
        lblTotalResults.text = val.total
        
        workings = val.input
        lblInputWorkings.textColor = .white
        
        UIView.animate(withDuration: 0.3) {
            self.viewHistory.isHidden.toggle()
            self.viewHistory.alpha = self.viewHistory.isHidden ? 0.0 : 1.0
        }
    }
    
}
extension Character {
    var isDigit: Bool {
        return "0"..."9" ~= self
    }
    
    var isOperator: Bool {
        return "+-*/".contains(self)
    }
}
extension NSExpression {
    
    func toFloatingPoint() -> NSExpression {
        switch expressionType {
        case .constantValue:
            if let value = constantValue as? NSNumber {
                return NSExpression(forConstantValue: NSNumber(value: value.doubleValue))
            }
        case .function:
            let newArgs = arguments.map { $0.map { $0.toFloatingPoint() } }
            return NSExpression(forFunction: operand, selectorName: function, arguments: newArgs)
        case .conditional:
            return NSExpression(forConditional: predicate, trueExpression: self.true.toFloatingPoint(), falseExpression: self.false.toFloatingPoint())
        case .unionSet:
            return NSExpression(forUnionSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .intersectSet:
            return NSExpression(forIntersectSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .minusSet:
            return NSExpression(forMinusSet: left.toFloatingPoint(), with: right.toFloatingPoint())
        case .subquery:
            if let subQuery = collection as? NSExpression {
                return NSExpression(forSubquery: subQuery.toFloatingPoint(), usingIteratorVariable: variable, predicate: predicate)
            }
        case .aggregate:
            if let subExpressions = collection as? [NSExpression] {
                return NSExpression(forAggregate: subExpressions.map { $0.toFloatingPoint() })
            }
        case .anyKey:
            fatalError("anyKey not yet implemented")
        case .block:
            fatalError("block not yet implemented")
        case .evaluatedObject, .variable, .keyPath:
            break // Nothing to do here
        @unknown default:
            break
        }
        return self
    }
}
