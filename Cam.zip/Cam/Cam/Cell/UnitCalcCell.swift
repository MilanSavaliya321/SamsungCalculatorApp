//
//  UnitCalcCell.swift
//  Cam
//
//  Created by IOS on 01/02/24.
//

import UIKit

class UnitCalcCell: UICollectionViewCell {

    @IBOutlet weak var viewbg: UIView!
    @IBOutlet weak var lblTitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        let radius = UIDevice().userInterfaceIdiom == .pad ? 70:40
        viewbg.layer.cornerRadius = CGFloat(radius) / 2
    }
    
//    override func layoutSubviews() {
//        super.layoutSubviews()
//        let radius = UIDevice().userInterfaceIdiom == .pad ? 70:40
//        viewbg.layer.cornerRadius = CGFloat(radius) / 2
//    }
}
