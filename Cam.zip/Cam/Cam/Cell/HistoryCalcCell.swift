//
//  HistoryCalcCell.swift
//  Cam
//
//  Created by IOS on 31/01/24.
//

import UIKit

class HistoryCalcCell: UITableViewCell {

    @IBOutlet weak var lblCalc: UILabel!
    @IBOutlet weak var lblResult: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        selectionStyle = .none
    }

}
