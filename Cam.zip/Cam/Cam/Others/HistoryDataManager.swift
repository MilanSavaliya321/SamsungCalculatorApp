//
//  HistoryDataManager.swift
//  Cam
//
//  Created by IOS on 01/02/24.
//

import Foundation

class HistoryModel: Codable {
    var id: UUID
    var input: String
    var total: String
    
    init(id: UUID, input: String, total: String) {
        self.id = id
        self.input = input
        self.total = total
    }
}

class HistoryDataManager {
    static let shared = HistoryDataManager()

    private let userDefaults = UserDefaults.standard
    private let key = "HistoryModelArrayKey"

    var arrHistoryModel: [HistoryModel] {
        get {
            if let data = userDefaults.data(forKey: key),
               let array = try? JSONDecoder().decode([HistoryModel].self, from: data) {
                return array
            }
            return []
        }
        set {
            if let data = try? JSONEncoder().encode(newValue) {
                userDefaults.set(data, forKey: key)
                UserDefaults.standard.synchronize()
            }
        }
    }

    func addModel(input: String, total: String) {
        let newModel = HistoryModel(id: UUID(), input: input, total: total)
        var newArray = arrHistoryModel
        newArray.append(newModel)
        arrHistoryModel = newArray
    }
    
    func removeAll() {
        let keyToRemove = key
        UserDefaults.standard.removeObject(forKey: keyToRemove)
        UserDefaults.standard.synchronize()
    }
}
