//
//  UnitDataManager.swift
//  UnitConverter-SwiftUI
//
//  Created by Robert P on 12.05.2021.
//

import Foundation


enum Category: String, CaseIterable {
    case area = "Area"
    case length = "length"
    case temperature = "Temperature"
    case volume = "Volume"
    case mass = "Mass"
    case data = "Data"
    case speed = "Speed"
    case time = "Time"
    case pressure = "Pressure"
    case angle = "Angle"
}

final class UnitDataManager: NSObject {
    
    func convert<T: Dimension>(value: String, unit1: T, unit2: T) -> Double {
        if value == "" { return 0 }
        return Measurement(value: (Double(value) ?? 0.0), unit: unit1).converted(to: unit2).value
    }
    
    func selectedtUnits(category: Category) -> [Dimension] {
        switch category {
        case .area:
            return [UnitArea.squareMegameters, UnitArea.squareKilometers, UnitArea.squareMeters, UnitArea.squareCentimeters, UnitArea.squareMillimeters, UnitArea.squareNanometers, UnitArea.squareInches, UnitArea.squareFeet, UnitArea.squareYards, UnitArea.squareMiles, UnitArea.acres, UnitArea.ares, UnitArea.hectares] as [Dimension]
            
        case .length:
            return [UnitLength.megameters, UnitLength.kilometers, UnitLength.hectometers, UnitLength.decameters, UnitLength.meters, UnitLength.decimeters, UnitLength.centimeters, UnitLength.centimeters, UnitLength.millimeters, UnitLength.micrometers, UnitLength.nanometers, UnitLength.picometers, UnitLength.inches, UnitLength.feet, UnitLength.yards, UnitLength.miles, UnitLength.scandinavianMiles, UnitLength.lightyears, UnitLength.nauticalMiles, UnitLength.fathoms, UnitLength.astronomicalUnits, UnitLength.parsecs] as [Dimension]
            
        case .pressure:
            return [UnitPressure.newtonsPerMetersSquared, UnitPressure.gigapascals, UnitPressure.megapascals, UnitPressure.kilopascals, UnitPressure.hectopascals, UnitPressure.inchesOfMercury, UnitPressure.bars, UnitPressure.millibars, UnitPressure.millimetersOfMercury, UnitPressure.poundsForcePerSquareInch] as [Dimension]
            
        case .temperature:
            return [UnitTemperature.celsius, UnitTemperature.fahrenheit, UnitTemperature.kelvin] as [Dimension]
            
        case .volume:
            return [UnitVolume.megaliters, UnitVolume.kiloliters, UnitVolume.liters, UnitVolume.deciliters, UnitVolume.centiliters, UnitVolume.milliliters, UnitVolume.cubicKilometers, UnitVolume.cubicKilometers, UnitVolume.cubicMeters, UnitVolume.cubicDecimeters, UnitVolume.cubicCentimeters, UnitVolume.cubicMillimeters, UnitVolume.cubicInches, UnitVolume.cubicFeet, UnitVolume.cubicYards, UnitVolume.cubicMiles, UnitVolume.acreFeet, UnitVolume.bushels, UnitVolume.teaspoons, UnitVolume.tablespoons, UnitVolume.fluidOunces, UnitVolume.cups, UnitVolume.pints, UnitVolume.quarts, UnitVolume.gallons, UnitVolume.imperialTeaspoons, UnitVolume.imperialTablespoons, UnitVolume.imperialFluidOunces, UnitVolume.imperialPints, UnitVolume.imperialQuarts, UnitVolume.imperialGallons, UnitVolume.metricCups] as [Dimension]
            
        case .mass:
            return [UnitMass.kilograms, UnitMass.grams, UnitMass.decigrams, UnitMass.centigrams, UnitMass.milligrams, UnitMass.micrograms, UnitMass.nanograms, UnitMass.picograms, UnitMass.ounces, UnitMass.pounds, UnitMass.stones, UnitMass.metricTons, UnitMass.shortTons, UnitMass.carats, UnitMass.ouncesTroy, UnitMass.slugs] as [Dimension]
            
        case .angle:
            return [UnitAngle.degrees, UnitAngle.arcMinutes, UnitAngle.arcSeconds, UnitAngle.radians, UnitAngle.gradians, UnitAngle.revolutions] as [Dimension]
        case .speed:
            return [UnitSpeed.metersPerSecond, UnitSpeed.kilometersPerHour, UnitSpeed.milesPerHour, UnitSpeed.knots, UnitSpeed.milesPerHour] as [Dimension]
        case .time:
            return [UnitDuration.hours, UnitDuration.minutes, UnitDuration.seconds, UnitDuration.milliseconds, UnitDuration.microseconds, UnitDuration.nanoseconds, UnitDuration.nanoseconds, UnitDuration.picoseconds] as [Dimension]
        case .data:
            return [ UnitInformationStorage.bytes, UnitInformationStorage.bits, UnitInformationStorage.nibbles, UnitInformationStorage.yottabytes, UnitInformationStorage.zettabytes, UnitInformationStorage.exabytes, UnitInformationStorage.petabytes, UnitInformationStorage.terabytes, UnitInformationStorage.gigabytes, UnitInformationStorage.megabytes, UnitInformationStorage.kilobytes, UnitInformationStorage.yottabits, UnitInformationStorage.zettabits, UnitInformationStorage.exabits, UnitInformationStorage.petabits, UnitInformationStorage.terabits, UnitInformationStorage.gigabits, UnitInformationStorage.megabits, UnitInformationStorage.kilobits, UnitInformationStorage.yobibytes, UnitInformationStorage.zebibytes, UnitInformationStorage.exbibytes, UnitInformationStorage.pebibytes, UnitInformationStorage.tebibytes, UnitInformationStorage.gibibytes, UnitInformationStorage.mebibytes, UnitInformationStorage.kibibytes, UnitInformationStorage.yobibits, UnitInformationStorage.zebibits, UnitInformationStorage.exbibits, UnitInformationStorage.pebibits, UnitInformationStorage.tebibits, UnitInformationStorage.gibibits, UnitInformationStorage.mebibits, UnitInformationStorage.kibibits]  as [Dimension]
        }
    }
    
    func selectedUnitTitles(category: Category) -> [String] {
        switch category {
        case .area:
            return ["Square Megameters", "Square Kilometers", "Square Meters", "Square Centimeters", "Square Millimeters", "Square Nanometers", "Square Inches", "Square Feet", "Square Yards", "Square Miles", "Acres", "Ares", "Hectares"]
            
        case .length:
            return ["Megameters", "Kilometers", "Hectometers", "Decameters", "Meters", "Decimeters", "Centimeters", "Millimeters", "Micrometers", "Nanometers", "Picometers", "Inches", "Feet", "Yards", "Miles", "Scandinavian Miles", "Lightyears", "Nautical Miles", "Fathoms", "Astronomical Units", "Parsecs"]
            
        case .pressure:
            return ["Newtons per Square Meters", "Gigapascals", "Megapascals", "Kilopascals", "Hectopascals", "Inches of Mercury", "Bars", "Millibars", "Millimeters of Mercury", "Pounds Force per Square Inch"]
            
        case .temperature:
            return ["Celsius", "Fahrenheit", "Kelvin"]
            
        case .volume:
            return ["Megaliters", "Kiloliters", "Liters", "Deciliters", "Centiliters", "Milliliters", "Cubic Kilometers", "Cubic Meters", "Cubic Decimeters", "Cubic Centimeters", "Cubic Millimeters", "Cubic Inches", "Cubic Feet", "Cubic Yards", "Cubic Miles", "Acre Feet", "Bushels", "Teaspoons", "Tablespoons", "Fluid Ounces", "Cups", "Pints", "Quarts", "Gallons", "Imperial Teaspoons", "Imperial Tablespoons", "Imperial Fluid Ounces", "Imperial Pints", "Imperial Quarts", "Imperial Gallons", "Metric Cups"]
            
        case .mass:
            return ["Kilograms", "Grams", "Decigrams", "Centigrams", "Milligrams", "Micrograms", "Nanograms", "Picograms", "Ounces", "Pounds", "Stones", "Metric Tons", "Short Tons", "Carats", "Troy Ounces", "Slugs"]
            
        case .angle:
            return ["Degrees", "Arc Minutes", "Arc Seconds", "Radians", "Gradians", "Revolutions"]
            
        case .speed:
            return ["Meters per Second", "Kilometers per Hour", "Miles per Hour", "Knots"]
            
        case .time:
            return ["Hours", "Minutes", "Seconds", "Milliseconds", "Microseconds", "Nanoseconds", "Picoseconds"]
        case .data:
            return [
                "Bytes", "Bits", "Nibbles", "Yottabytes", "Zettabytes", "Exabytes", "Petabytes", "Terabytes", "Gigabytes", "Megabytes", "Kilobytes", "Yottabits", "Zettabits", "Exabits", "Petabits", "Terabits", "Gigabits", "Megabits", "Kilobits", "Yobibytes", "Zebibytes", "Exbibytes", "Pebibytes", "Tebibytes", "Gibibytes", "Mebibytes", "Kibibytes", "Yobibits", "Zebibits", "Exbibits", "Pebibits", "Tebibits", "Gibibits", "Mebibits", "Kibibits"]
        }
    }
    
    func selectedUnitTitlesAndSymbols(category: Category) -> [(title: String, symbol: String)] {
        switch category {
        case .area:
            return [("Square Megameters", UnitArea.squareMegameters.symbol),
                    ("Square Kilometers", UnitArea.squareKilometers.symbol),
                    ("Square Meters", UnitArea.squareMeters.symbol),
                    ("Square Centimeters", UnitArea.squareCentimeters.symbol),
                    ("Square Millimeters", UnitArea.squareMillimeters.symbol),
                    ("Square Nanometers", UnitArea.squareNanometers.symbol),
                    ("Square Inches", UnitArea.squareInches.symbol),
                    ("Square Feet", UnitArea.squareFeet.symbol),
                    ("Square Yards", UnitArea.squareYards.symbol),
                    ("Square Miles", UnitArea.squareMiles.symbol),
                    ("Acres", UnitArea.acres.symbol),
                    ("Ares", UnitArea.ares.symbol),
                    ("Hectares", UnitArea.hectares.symbol)]
            
        case .length:
            return [("Megameters", UnitLength.megameters.symbol),
                    ("Kilometers", UnitLength.kilometers.symbol),
                    ("Hectometers", UnitLength.hectometers.symbol),
                    ("Decameters", UnitLength.decameters.symbol),
                    ("Meters", UnitLength.meters.symbol),
                    ("Decimeters", UnitLength.decimeters.symbol),
                    ("Centimeters", UnitLength.centimeters.symbol),
                    ("Millimeters", UnitLength.millimeters.symbol),
                    ("Micrometers", UnitLength.micrometers.symbol),
                    ("Nanometers", UnitLength.nanometers.symbol),
                    ("Picometers", UnitLength.picometers.symbol),
                    ("Inches", UnitLength.inches.symbol),
                    ("Feet", UnitLength.feet.symbol),
                    ("Yards", UnitLength.yards.symbol),
                    ("Miles", UnitLength.miles.symbol),
                    ("Scandinavian Miles", UnitLength.scandinavianMiles.symbol),
                    ("Lightyears", UnitLength.lightyears.symbol),
                    ("Nautical Miles", UnitLength.nauticalMiles.symbol),
                    ("Fathoms", UnitLength.fathoms.symbol),
                    ("Astronomical Units", UnitLength.astronomicalUnits.symbol),
                    ("Parsecs", UnitLength.parsecs.symbol)]
            
        case .pressure:
            return [("Newtons per Square Meters", UnitPressure.newtonsPerMetersSquared.symbol),
                    ("Gigapascals", UnitPressure.gigapascals.symbol),
                    ("Megapascals", UnitPressure.megapascals.symbol),
                    ("Kilopascals", UnitPressure.kilopascals.symbol),
                    ("Hectopascals", UnitPressure.hectopascals.symbol),
                    ("Inches of Mercury", UnitPressure.inchesOfMercury.symbol),
                    ("Bars", UnitPressure.bars.symbol),
                    ("Millibars", UnitPressure.millibars.symbol),
                    ("Millimeters of Mercury", UnitPressure.millimetersOfMercury.symbol),
                    ("Pounds Force per Square Inch", UnitPressure.poundsForcePerSquareInch.symbol)]
            
        case .temperature:
            return [("Celsius", UnitTemperature.celsius.symbol),
                    ("Fahrenheit", UnitTemperature.fahrenheit.symbol),
                    ("Kelvin", UnitTemperature.kelvin.symbol)]
            
        case .volume:
            return [("Megaliters", UnitVolume.megaliters.symbol),
                    ("Kiloliters", UnitVolume.kiloliters.symbol),
                    ("Liters", UnitVolume.liters.symbol),
                    ("Deciliters", UnitVolume.deciliters.symbol),
                    ("Centiliters", UnitVolume.centiliters.symbol),
                    ("Milliliters", UnitVolume.milliliters.symbol),
                    ("Cubic Kilometers", UnitVolume.cubicKilometers.symbol),
                    ("Cubic Meters", UnitVolume.cubicMeters.symbol),
                    ("Cubic Decimeters", UnitVolume.cubicDecimeters.symbol),
                    ("Cubic Centimeters", UnitVolume.cubicCentimeters.symbol),
                    ("Cubic Millimeters", UnitVolume.cubicMillimeters.symbol),
                    ("Cubic Inches", UnitVolume.cubicInches.symbol),
                    ("Cubic Feet", UnitVolume.cubicFeet.symbol),
                    ("Cubic Yards", UnitVolume.cubicYards.symbol),
                    ("Cubic Miles", UnitVolume.cubicMiles.symbol),
                    ("Acre Feet", UnitVolume.acreFeet.symbol),
                    ("Bushels", UnitVolume.bushels.symbol),
                    ("Teaspoons", UnitVolume.teaspoons.symbol),
                    ("Tablespoons", UnitVolume.tablespoons.symbol),
                    ("Fluid Ounces", UnitVolume.fluidOunces.symbol),
                    ("Cups", UnitVolume.cups.symbol),
                    ("Pints", UnitVolume.pints.symbol),
                    ("Quarts", UnitVolume.quarts.symbol),
                    ("Gallons", UnitVolume.gallons.symbol),
                    ("Imperial Teaspoons", UnitVolume.imperialTeaspoons.symbol),
                    ("Imperial Tablespoons", UnitVolume.imperialTablespoons.symbol),
                    ("Imperial Fluid Ounces", UnitVolume.imperialFluidOunces.symbol),
                    ("Imperial Pints", UnitVolume.imperialPints.symbol),
                    ("Imperial Quarts", UnitVolume.imperialQuarts.symbol),
                    ("Imperial Gallons", UnitVolume.imperialGallons.symbol),
                    ("Metric Cups", UnitVolume.metricCups.symbol)]
            
        case .mass:
            return [("Kilograms", UnitMass.kilograms.symbol),
                    ("Grams", UnitMass.grams.symbol),
                    ("Decigrams", UnitMass.decigrams.symbol),
                    ("Centigrams", UnitMass.centigrams.symbol),
                    ("Milligrams", UnitMass.milligrams.symbol),
                    ("Micrograms", UnitMass.micrograms.symbol),
                    ("Nanograms", UnitMass.nanograms.symbol),
                    ("Picograms", UnitMass.picograms.symbol),
                    ("Ounces", UnitMass.ounces.symbol),
                    ("Pounds", UnitMass.pounds.symbol),
                    ("Stones", UnitMass.stones.symbol),
                    ("Metric Tons", UnitMass.metricTons.symbol),
                    ("Short Tons", UnitMass.shortTons.symbol),
                    ("Carats", UnitMass.carats.symbol),
                    ("Troy Ounces", UnitMass.ouncesTroy.symbol),
                    ("Slugs", UnitMass.slugs.symbol)]
            
        case .angle:
            return [("Degrees", UnitAngle.degrees.symbol),
                    ("Arc Minutes", UnitAngle.arcMinutes.symbol),
                    ("Arc Seconds", UnitAngle.arcSeconds.symbol),
                    ("Radians", UnitAngle.radians.symbol),
                    ("Gradians", UnitAngle.gradians.symbol),
                    ("Revolutions", UnitAngle.revolutions.symbol)]
            
        case .speed:
            return [("Meters per Second", UnitSpeed.metersPerSecond.symbol),
                    ("Kilometers per Hour", UnitSpeed.kilometersPerHour.symbol),
                    ("Miles per Hour", UnitSpeed.milesPerHour.symbol),
                    ("Knots", UnitSpeed.knots.symbol)]
            
        case .time:
            return [("Hours", UnitDuration.hours.symbol),
                    ("Minutes", UnitDuration.minutes.symbol),
                    ("Seconds", UnitDuration.seconds.symbol),
                    ("Milliseconds", UnitDuration.milliseconds.symbol),
                    ("Microseconds", UnitDuration.microseconds.symbol),
                    ("Nanoseconds", UnitDuration.nanoseconds.symbol),
                    ("Picoseconds", UnitDuration.picoseconds.symbol)]
        case .data:
            return [
                ("Bytes", UnitInformationStorage.bytes.symbol),
                ("Bits", UnitInformationStorage.bits.symbol),
                ("Nibbles", UnitInformationStorage.nibbles.symbol),
                ("Yottabytes", UnitInformationStorage.yottabytes.symbol),
                ("Zettabytes", UnitInformationStorage.zettabytes.symbol),
                ("Exabytes", UnitInformationStorage.exabytes.symbol),
                ("Petabytes", UnitInformationStorage.petabytes.symbol),
                ("Terabytes", UnitInformationStorage.terabytes.symbol),
                ("Gigabytes", UnitInformationStorage.gigabytes.symbol),
                ("Megabytes", UnitInformationStorage.megabytes.symbol),
                ("Kilobytes", UnitInformationStorage.kilobytes.symbol),
                ("Yottabits", UnitInformationStorage.yottabits.symbol),
                ("Zettabits", UnitInformationStorage.zettabits.symbol),
                ("Exabits", UnitInformationStorage.exabits.symbol),
                ("Petabits", UnitInformationStorage.petabits.symbol),
                ("Terabits", UnitInformationStorage.terabits.symbol),
                ("Gigabits", UnitInformationStorage.gigabits.symbol),
                ("Megabits", UnitInformationStorage.megabits.symbol),
                ("Kilobits", UnitInformationStorage.kilobits.symbol),
                ("Yobibytes", UnitInformationStorage.yobibytes.symbol),
                ("Zebibytes", UnitInformationStorage.zebibytes.symbol),
                ("Exbibytes", UnitInformationStorage.exbibytes.symbol),
                ("Pebibytes", UnitInformationStorage.pebibytes.symbol),
                ("Tebibytes", UnitInformationStorage.tebibytes.symbol),
                ("Gibibytes", UnitInformationStorage.gibibytes.symbol),
                ("Mebibytes", UnitInformationStorage.mebibytes.symbol),
                ("Kibibytes", UnitInformationStorage.kibibytes.symbol),
                ("Yobibits", UnitInformationStorage.yobibits.symbol),
                ("Zebibits", UnitInformationStorage.zebibits.symbol),
                ("Exbibits", UnitInformationStorage.exbibits.symbol),
                ("Pebibits", UnitInformationStorage.pebibits.symbol),
                ("Tebibits", UnitInformationStorage.tebibits.symbol),
                ("Gibibits", UnitInformationStorage.gibibits.symbol),
                ("Mebibits", UnitInformationStorage.mebibits.symbol),
                ("Kibibits", UnitInformationStorage.kibibits.symbol)
            ]
        }
    }
}
